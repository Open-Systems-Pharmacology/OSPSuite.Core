﻿namespace OSPSuite.Core.Chart.Simulations
{
   public class SimulationPredictedVsObservedChart : PredictedVsObservedChart
   {
   }

   public class SimulationResidualVsTimeChart : AnalysisChartWithLocalRepositories
   {
   }
}