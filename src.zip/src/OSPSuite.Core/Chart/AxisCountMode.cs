﻿namespace OSPSuite.Core.Chart
{
   public enum BarType
   {
      Stacked,
      SideBySide
   }

   public enum AxisCountMode
   {
      Count,
      Percent
   }
}