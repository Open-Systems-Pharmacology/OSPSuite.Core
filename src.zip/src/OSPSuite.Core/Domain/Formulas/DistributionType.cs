﻿namespace OSPSuite.Core.Domain.Formulas
{
   public enum DistributionType
   {
      Normal,
      LogNormal,
      Uniform,
      Discrete,
      Unknown,
   }
}