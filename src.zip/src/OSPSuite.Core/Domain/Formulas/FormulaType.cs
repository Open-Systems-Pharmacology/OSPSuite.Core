﻿namespace OSPSuite.Core.Domain.Formulas
{
   public enum FormulaType
   {
      Distribution,
      Rate,
      Constant,
      Table
   }

}