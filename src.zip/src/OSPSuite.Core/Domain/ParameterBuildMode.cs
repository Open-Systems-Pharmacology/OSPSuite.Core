﻿namespace OSPSuite.Core.Domain
{
   public enum ParameterBuildMode
   {
      Local,
      Global
   }
}