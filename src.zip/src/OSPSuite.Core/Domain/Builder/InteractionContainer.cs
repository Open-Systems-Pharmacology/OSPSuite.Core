﻿namespace OSPSuite.Core.Domain.Builder
{
   /// <summary>
   /// Container defining the possible interactions triggered by a <see cref="MoleculeBuilder"/>
   /// </summary>
   public class InteractionContainer : Container
   {
       
   }
}