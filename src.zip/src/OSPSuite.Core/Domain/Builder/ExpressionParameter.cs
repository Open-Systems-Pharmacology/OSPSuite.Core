﻿namespace OSPSuite.Core.Domain.Builder
{
   public class ExpressionParameter : ParameterValue
   {
   }
}