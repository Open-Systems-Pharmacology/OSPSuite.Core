﻿namespace OSPSuite.Core.Domain.Builder
{
   public class IndividualParameter : ParameterValue
   {
   }
}