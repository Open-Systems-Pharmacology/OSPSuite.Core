﻿using OSPSuite.Utility.Collections;

namespace OSPSuite.Core.Domain.Repositories
{
   public interface ISimulationRepository : IRepository<ISimulation>
   {
       
   }
}