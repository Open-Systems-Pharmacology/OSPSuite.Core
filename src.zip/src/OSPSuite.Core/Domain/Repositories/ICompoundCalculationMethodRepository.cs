using OSPSuite.Utility.Collections;

namespace OSPSuite.Core.Domain.Repositories
{
   public interface ICompoundCalculationMethodRepository : IRepository<CalculationMethod>
   {
   }
}