﻿namespace OSPSuite.Core.Domain.Populations
{
   public class RandomValue
   {
      public double Value { get; set; }
      public double Percentile { get; set; }
   }
}