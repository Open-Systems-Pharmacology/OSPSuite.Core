namespace OSPSuite.Core.Domain
{
   public enum Scalings
   {
      Linear,
      Log
   }
}