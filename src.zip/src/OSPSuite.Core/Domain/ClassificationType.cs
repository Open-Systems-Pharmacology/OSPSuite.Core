namespace OSPSuite.Core.Domain
{
   public enum ClassificationType
   {
      Unknown,
      ObservedData,
      Simulation,
      Comparison,
      ParameterIdentification,
      SensitiviyAnalysis,
      QualificationPlan,
      Module
   }
}