﻿namespace OSPSuite.Core.Domain
{
   public interface IFormulaUsable : IWithDisplayUnit, IWithValue, IEntity
   {
   }
}