﻿namespace OSPSuite.Core.Diagram
{
   public interface IJournalPageLink : IBaseLink
   {
   }
}
