﻿namespace OSPSuite.Core.Diagram
{
   public interface IReactionNode : IElementBaseNode
   {
       
   }
}