namespace OSPSuite.Core.Diagram
{
   public interface IWithVisible
   {
      bool Visible { get; set; }
   }
}