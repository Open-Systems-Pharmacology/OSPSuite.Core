﻿namespace OSPSuite.Core.Diagram
{
   public interface IRelatedItemNode : IBaseNode
   {
   }
}
