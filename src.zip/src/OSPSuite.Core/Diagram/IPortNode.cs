﻿namespace OSPSuite.Core.Diagram
{
   public interface IPortNode : IHasLayoutInfo
   {
      object PortNodeParent { get; }
   }
}