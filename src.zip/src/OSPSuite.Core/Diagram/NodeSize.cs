﻿namespace OSPSuite.Core.Diagram
{
   public enum NodeSize
   {
      Small = 50,
      Middle = 100,
      Large = 150
   }
}