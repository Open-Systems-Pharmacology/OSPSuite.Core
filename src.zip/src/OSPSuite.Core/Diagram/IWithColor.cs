namespace OSPSuite.Core.Diagram
{
   public interface IWithColor
   {
      void SetColorFrom(IDiagramColors diagramColors);
   }
}