﻿namespace OSPSuite.Core.Batch
{
   public class ParameterValue
   {
      public string Path { get; set; }
      public double Value { get; set; }
   }
}